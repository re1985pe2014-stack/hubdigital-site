/* Painel Anti-Fatura: funciona offline depois da primeira visita.
   Ao publicar uma versão nova, troque o número em VERSAO. */
const VERSAO = 'hd-anti-fatura-v2-1';
const ARQUIVOS = [
  './', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png',
  'fonts/space-grotesk-latin-400-normal.woff2', 'fonts/space-grotesk-latin-600-normal.woff2', 'fonts/space-grotesk-latin-700-normal.woff2',
  'fonts/ibm-plex-mono-latin-500-normal.woff2', 'fonts/ibm-plex-mono-latin-700-normal.woff2'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSAO).then(c => c.addAll(ARQUIVOS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSAO).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  const pagina = req.mode === 'navigate';
  if (pagina) {
    // página: tenta a rede (pega atualizações) e cai para o cache se estiver offline
    e.respondWith(fetch(req).then(r => { const cp = r.clone(); caches.open(VERSAO).then(c => c.put('index.html', cp)); return r; })
      .catch(() => caches.match('index.html')));
  } else {
    e.respondWith(caches.match(req, { ignoreSearch: true }).then(hit => hit || fetch(req)));
  }
});
